This project describes an instance of student information system.
Admin can access the page containing the student details including
name,age,phone no etc.Admin can download those details of student 
by clicking on student id.

 



Student Name          Email ID                          USN

APOORVA AN       apoorva9997@gmail.com               1VE17CS013
BHARATHI S       bharathishankar35@gmail.com         1VE17CS023
CHANDANA B G     gowdachandana52@gmail.com           1VE17CS027
PALLAVI          pallavi.p2323@gmail.com             1VE17CS078
RAMAYA R         ramyaselfie18@gmail.com             1VE17CS091
RAUSHAN KUMAR    rkraushan1305@gmail.com             1VE17CS094
VANISHREE H A    vanishree2460@gmail.com             1VE17CS119


batch2 code -https://github.com/Raushan431/DJANGO-code.git